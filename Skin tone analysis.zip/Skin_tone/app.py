from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import cv2, os

app = Flask(__name__)
model = load_model("skin_tone_model_new.h5")

UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Brand recommendations based on skin tone
brand_recommendations = {
    "White": [
        {"name": "CeraVe Moisturizer", "desc": "Hydrating for light skin tone"},
        {"name": "La Roche-Posay Sunscreen", "desc": "SPF 50 protection for fair tones"},
    ],
    "Brown": [
        {"name": "Neutrogena Hydro Boost", "desc": "Brightens medium skin tones"},
        {"name": "The Ordinary Niacinamide", "desc": "Balances pigmentation"},
    ],
    "Black": [
        {"name": "SheaMoisture Lotion", "desc": "Rich moisture for deeper tones"},
        {"name": "Fenty Beauty Primer", "desc": "Great base for darker complexions"},
    ],
}

def preprocess_image(img_path):
    # Read image
    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Skin segmentation using HSV
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    lower = np.array([0, 48, 80], dtype=np.uint8)
    upper = np.array([20, 255, 255], dtype=np.uint8)
    mask = cv2.inRange(hsv, lower, upper)
    skin = cv2.bitwise_and(img, img, mask=mask)

    # Resize and prepare for model
    img_resized = cv2.resize(skin, (224, 224))
    img_array = np.expand_dims(img_resized / 255.0, axis=0)
    return img_array

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["file"]
        if file:
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(file_path)
            
            img_array = preprocess_image(file_path)
            preds = model.predict(img_array)
            classes = ["Black", "Brown", "White"]
            label = classes[np.argmax(preds)]
            
            brands = brand_recommendations[label]
            return render_template("index.html", label=label, brands=brands, image=file.filename)
    
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
